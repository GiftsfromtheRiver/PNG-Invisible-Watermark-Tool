// watermark_tool 自动化测试
#include "watermark.h"
#include "lodepng.h"
#include <iostream>
#include <cassert>
#include <vector>
#include <string>
#include <cstring>

using namespace watermark;

static int pass = 0, fail = 0;

#define CHECK(cond, msg) do { \
    if (cond) { pass++; std::cout << "  [PASS] " << msg << "\n"; } \
    else { fail++; std::cout << "  [FAIL] " << msg << "\n"; } \
} while(0)

// 生成测试PNG图片
static void make_test_png(const std::string& path, uint32_t w, uint32_t h, bool has_alpha) {
    std::vector<uint8_t> image(w * h * (has_alpha ? 4 : 3));
    // 用伪随机填充，模拟自然图像
    uint64_t rng = 12345;
    for (size_t i = 0; i < image.size(); i++) {
        rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
        image[i] = rng & 0xFF;
    }
    unsigned error;
    if (has_alpha) {
        error = lodepng::encode(path, image, w, h, LCT_RGBA, 8);
    } else {
        error = lodepng::encode(path, image, w, h, LCT_RGB, 8);
    }
    assert(error == 0);
}

// ---- 测试组 ----

void test_basic_embed_extract() {
    std::cout << "\n=== 基本嵌入/提取 ===\n";
    
    make_test_png("/tmp/test_wm_rgba.png", 100, 100, true);
    
    std::string text = "Hello, 这是一段不可见水印!";
    uint64_t salt = 0xDEADBEEF;
    
    auto er = embed_text("/tmp/test_wm_rgba.png", "/tmp/test_wm_out_rgba.png", text, salt);
    CHECK(er.success, "RGBA 嵌入成功");
    CHECK(er.used_bits > 0, "使用了 " + std::to_string(er.used_bits) + " bits");
    
    auto xr = extract_text("/tmp/test_wm_out_rgba.png", salt);
    CHECK(xr.success, "RGBA 提取成功");
    CHECK(xr.text == text, "文本完全一致: \"" + xr.text + "\"");
}

void test_rgb_image() {
    std::cout << "\n=== RGB无Alpha通道 ===\n";
    
    make_test_png("/tmp/test_wm_rgb.png", 100, 100, false);
    
    auto cap = get_capacity("/tmp/test_wm_rgb.png");
    CHECK(cap.has_alpha == false, "检测为RGB(无A通道)");
    CHECK(cap.available_channels == 3, "可用3通道");
    
    std::string text = "RGB image watermark test 中文测试";
    uint64_t salt = 42;
    
    auto er = embed_text("/tmp/test_wm_rgb.png", "/tmp/test_wm_out_rgb.png", text, salt);
    CHECK(er.success, "RGB 嵌入成功");
    CHECK(er.has_alpha == false, "输出保持RGB格式");
    
    auto xr = extract_text("/tmp/test_wm_out_rgb.png", salt);
    CHECK(xr.success, "RGB 提取成功");
    CHECK(xr.text == text, "文本完全一致");
}

void test_wrong_salt() {
    std::cout << "\n=== 错误盐值测试 ===\n";
    
    make_test_png("/tmp/test_wm_salt.png", 80, 80, true);
    
    std::string text = "secret message";
    embed_text("/tmp/test_wm_salt.png", "/tmp/test_wm_salt_out.png", text, 111);
    
    auto xr = extract_text("/tmp/test_wm_salt_out.png", 222);
    // 错误salt应该提取出乱码或失败
    CHECK(xr.text != text, "错误salt提取结果不等于原文 (正确!)");
}

void test_capacity_query() {
    std::cout << "\n=== 容量查询 ===\n";
    
    make_test_png("/tmp/test_wm_cap.png", 200, 200, true);
    
    auto cap = get_capacity("/tmp/test_wm_cap.png");
    CHECK(cap.width == 200, "宽度 200");
    CHECK(cap.height == 200, "高度 200");
    CHECK(cap.has_alpha == true, "RGBA 4通道");
    CHECK(cap.blocks_per_channel > 0, "每通道块数: " + std::to_string(cap.blocks_per_channel));
    CHECK(cap.max_text_bytes > 0, "最大字节: " + std::to_string(cap.max_text_bytes));
    
    std::cout << "  信息: " << cap.width << "x" << cap.height 
              << " " << cap.available_channels << "ch"
              << " blocks/ch=" << cap.blocks_per_channel
              << " max=" << cap.max_text_bytes << "bytes"
              << " ~" << cap.max_text_chars << "中文字\n";
}

void test_long_text() {
    std::cout << "\n=== 长文本嵌入 ===\n";
    
    make_test_png("/tmp/test_wm_long.png", 200, 200, true);
    
    auto cap = get_capacity("/tmp/test_wm_long.png");
    
    // 生成一段接近容量上限的文本
    std::string text;
    size_t target_bytes = cap.max_text_bytes - 10; // 留点余量
    for (size_t i = 0; i < target_bytes / 3; i++) {
        text += "中";  // UTF-8 3字节
    }
    
    uint64_t salt = 9999;
    auto er = embed_text("/tmp/test_wm_long.png", "/tmp/test_wm_long_out.png", text, salt);
    CHECK(er.success, "长文本嵌入成功 (" + std::to_string(text.size()) + " bytes)");
    
    auto xr = extract_text("/tmp/test_wm_long_out.png", salt);
    CHECK(xr.success, "长文本提取成功");
    CHECK(xr.text == text, "长文本完全一致");
}

void test_text_overflow() {
    std::cout << "\n=== 容量溢出测试 ===\n";
    
    make_test_png("/tmp/test_wm_tiny.png", 10, 10, true);
    
    auto cap = get_capacity("/tmp/test_wm_tiny.png");
    
    // 构造超长文本
    std::string long_text(cap.max_text_bytes + 100, 'X');
    
    auto er = embed_text("/tmp/test_wm_tiny.png", "/tmp/test_wm_tiny_out.png", long_text, 0);
    CHECK(!er.success, "超大文本正确拒绝");
}

void test_multiline_text() {
    std::cout << "\n=== 多行文本 ===\n";
    
    make_test_png("/tmp/test_wm_ml.png", 100, 100, true);
    
    std::string text = "第一行\n第二行\n第三行\nHello World!\n最后这行";
    uint64_t salt = 777;
    
    embed_text("/tmp/test_wm_ml.png", "/tmp/test_wm_ml_out.png", text, salt);
    auto xr = extract_text("/tmp/test_wm_ml_out.png", salt);
    CHECK(xr.text == text, "多行文本完全一致");
}

void test_special_chars() {
    std::cout << "\n=== 特殊字符/Emoji ===\n";
    
    make_test_png("/tmp/test_wm_special.png", 100, 100, true);
    
    std::string text = "emoji: 🎉🔥💡 | symbols: <>&\"' | unicode: αβγδ 日本語テスト";
    uint64_t salt = 555;
    
    embed_text("/tmp/test_wm_special.png", "/tmp/test_wm_special_out.png", text, salt);
    auto xr = extract_text("/tmp/test_wm_special_out.png", salt);
    CHECK(xr.text == text, "特殊字符完全一致");
}

int main() {
    std::cout << "========================================\n";
    std::cout << "  PNG 不可见水印工具 - 自动化测试\n";
    std::cout << "========================================\n";
    
    test_basic_embed_extract();
    test_rgb_image();
    test_wrong_salt();
    test_capacity_query();
    test_long_text();
    test_text_overflow();
    test_multiline_text();
    test_special_chars();
    
    std::cout << "\n========================================\n";
    std::cout << "  结果: " << pass << " 通过, " << fail << " 失败\n";
    std::cout << "========================================\n";
    
    return fail > 0 ? 1 : 0;
}
