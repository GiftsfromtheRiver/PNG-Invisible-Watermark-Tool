// ================================================================
// PNG 不可见水印工具
// 功能: 嵌入/提取/查询容量
// 技术: ±1 LSB Matching + 3×3 块标记 + 自适应通道 + 格式保持
// ================================================================

#include "watermark.h"
#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>

using namespace watermark;

static std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

static std::string read_line(const std::string& prompt) {
    std::cout << prompt;
    std::cout.flush();
    std::string line;
    std::getline(std::cin, line);
    return trim(line);
}

// 从字符串解析 salt（支持十进制和十六进制 0x 前缀）
static uint64_t parse_salt(const std::string& s) {
    if (s.empty()) return 0;
    try {
        if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
            return std::stoull(s.substr(2), nullptr, 16);
        }
        return std::stoull(s);
    } catch (...) {
        // 简单 hash
        uint64_t h = 14695981039346656037ULL;
        for (char c : s) {
            h ^= (uint8_t)c;
            h *= 1099511628211ULL;
        }
        return h;
    }
}

// ---- 嵌入水印 ----
static void do_embed() {
    std::cout << "\n===== 嵌入不可见水印 =====\n\n";
    
    std::string input = read_line("输入PNG图片路径: ");
    if (input.empty()) { std::cout << "已取消\n"; return; }
    
    std::string output = read_line("输出PNG图片路径: ");
    if (output.empty()) { std::cout << "已取消\n"; return; }
    
    std::string salt_str = read_line("种子密钥 (数字/字符串, 留空=0): ");
    uint64_t salt = parse_salt(salt_str);
    
    std::cout << "\n输入水印文本 (输入结束后按 Enter, 支持多行):\n";
    std::cout << "(单独一行输入 :END 结束)\n";
    std::string text;
    std::string line;
    while (std::getline(std::cin, line)) {
        if (trim(line) == ":END") break;
        if (!text.empty()) text += "\n";
        text += line;
    }
    
    if (text.empty()) {
        std::cout << "水印文本为空, 已取消\n";
        return;
    }
    
    std::cout << "\n正在嵌入...\n";
    auto result = embed_text(input, output, text, salt);
    
    if (result.success) {
        std::cout << "\n[OK] 水印嵌入成功!\n";
        std::cout << "  图片尺寸: " << result.width << " x " << result.height << "\n";
        std::cout << "  通道模式: " << (result.has_alpha ? "RGBA (4通道)" : "RGB (3通道)") << "\n";
        std::cout << "  嵌入数据: " << result.used_bits << " bits (" 
                  << text.size() << " 字节)\n";
        std::cout << "  总容量:   " << result.capacity_bits << " bits (" 
                  << (result.capacity_bits / 8) << " 字节)\n";
        std::cout << "  使用率:   " << (100.0 * result.used_bits / result.capacity_bits) << "%\n";
        std::cout << "  输出文件: " << output << "\n";
    } else {
        std::cout << "\n[FAIL] " << result.error_msg << "\n";
    }
}

// ---- 提取水印 ----
static void do_extract() {
    std::cout << "\n===== 提取不可见水印 =====\n\n";
    
    std::string input = read_line("隐写PNG图片路径: ");
    if (input.empty()) { std::cout << "已取消\n"; return; }
    
    std::string salt_str = read_line("种子密钥 (需与嵌入时一致): ");
    uint64_t salt = parse_salt(salt_str);
    
    std::cout << "\n正在提取...\n";
    auto result = extract_text(input, salt);
    
    if (result.success) {
        std::cout << "\n[OK] 水印提取成功!\n";
        std::cout << "  文本长度: " << result.text.size() << " 字节\n";
        std::cout << "\n--- 水印内容 ---\n";
        std::cout << result.text << "\n";
        std::cout << "--- 结束 ---\n";
    } else {
        std::cout << "\n[FAIL] " << result.error_msg << "\n";
    }
}

// ---- 查询容量 ----
static void do_capacity() {
    std::cout << "\n===== 查询水印容量 =====\n\n";
    
    std::string input = read_line("PNG图片路径: ");
    if (input.empty()) { std::cout << "已取消\n"; return; }
    
    auto info = get_capacity(input);
    
    if (info.width == 0) {
        std::cout << "\n[FAIL] 无法读取图片: " << input << "\n";
        return;
    }
    
    std::cout << "\n  图片尺寸: " << info.width << " x " << info.height << "\n";
    std::cout << "  总像素数: " << info.total_pixels << "\n";
    std::cout << "  通道模式: " << (info.has_alpha ? "RGBA (4通道)" : "RGB (3通道)") << "\n";
    std::cout << "  可用通道: " << info.available_channels << "\n";
    std::cout << "  每通道块数: " << info.blocks_per_channel << "\n";
    std::cout << "  总可用块数: " << (info.blocks_per_channel * info.available_channels) << "\n";
    std::cout << "  最大水印: " << info.max_text_bytes << " 字节\n";
    std::cout << "  约可嵌入: " << info.max_text_chars << " 个中文字符\n";
    std::cout << "\n  注: 采用 3×3 块标记模式, 每个数据bit需9个像素\n";
}

// ---- 主菜单 ----
int main(int argc, char* argv[]) {
    std::cout << "\n";
    std::cout << "╔══════════════════════════════════════╗\n";
    std::cout << "║    PNG 不可见水印工具 v1.0          ║\n";
    std::cout << "║    ±1 LSB Matching + 3x3 Block      ║\n";
    std::cout << "╚══════════════════════════════════════╝\n";
    std::cout << "\n";
    
    // 支持命令行直接执行
    if (argc >= 5) {
        std::string mode = argv[1];
        if (mode == "embed" && argc >= 6) {
            // embed <input> <output> <salt> <text>
            std::string input = argv[2];
            std::string output = argv[3];
            uint64_t salt = parse_salt(argv[4]);
            std::string text = argv[5];
            
            auto result = embed_text(input, output, text, salt);
            if (result.success) {
                std::cout << "OK: embedded " << result.used_bits << " bits into " << output << "\n";
                return 0;
            } else {
                std::cerr << "FAIL: " << result.error_msg << "\n";
                return 1;
            }
        } else if (mode == "extract" && argc >= 4) {
            // extract <input> <salt>
            std::string input = argv[2];
            uint64_t salt = parse_salt(argv[3]);
            
            auto result = extract_text(input, salt);
            if (result.success) {
                std::cout << result.text << "\n";
                return 0;
            } else {
                std::cerr << "FAIL: " << result.error_msg << "\n";
                return 1;
            }
        } else if (mode == "capacity" && argc >= 3) {
            // capacity <input>
            auto info = get_capacity(argv[2]);
            if (info.width > 0) {
                std::cout << info.width << "x" << info.height 
                         << " " << info.available_channels << "ch"
                         << " max=" << info.max_text_bytes << "bytes"
                         << " ~" << info.max_text_chars << "chars\n";
                return 0;
            } else {
                std::cerr << "FAIL: cannot read " << argv[2] << "\n";
                return 1;
            }
        }
    }
    
    // 交互模式
    while (true) {
        std::cout << "\n请选择功能:\n";
        std::cout << "  1. 嵌入水印 (Embed)\n";
        std::cout << "  2. 提取水印 (Extract)\n";
        std::cout << "  3. 查询容量 (Capacity)\n";
        std::cout << "  0. 退出\n";
        
        std::string choice = read_line("\n> ");
        
        if (choice == "1") do_embed();
        else if (choice == "2") do_extract();
        else if (choice == "3") do_capacity();
        else if (choice == "0") break;
        else std::cout << "无效选择\n";
    }
    
    std::cout << "\n再见!\n";
    return 0;
}
