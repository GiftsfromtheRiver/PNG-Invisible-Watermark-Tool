@echo off
chcp 65001 >nul
echo ================================
echo   PNG 不可见水印工具 - 编译
echo ================================

set GPP="C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe"

echo.
echo [1/2] 编译水印工具...
%GPP% -std=c++17 -O2 -o watermark_tool.exe watermark_tool.cpp watermark.cpp lodepng.cpp
if %errorlevel% neq 0 (
    echo [FAIL] 水印工具编译失败
    pause
    exit /b 1
)
echo [OK] watermark_tool.exe

echo.
echo [2/2] 编译测试程序...
%GPP% -std=c++17 -O2 -o test_watermark.exe test_watermark.cpp watermark.cpp lodepng.cpp
if %errorlevel% neq 0 (
    echo [FAIL] 测试程序编译失败
    pause
    exit /b 1
)
echo [OK] test_watermark.exe

echo.
echo ================================
echo   编译完成!
echo ================================
echo.
echo 使用方法:
echo   watermark_tool.exe          - 交互模式
echo   watermark_tool.exe embed input.png output.png salt "text"
echo   watermark_tool.exe extract output.png salt
echo   watermark_tool.exe capacity input.png
echo.
pause
