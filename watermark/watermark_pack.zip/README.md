# PNG 不可见水印工具 v1.0

## 技术方案

| 技术 | 说明 |
|------|------|
| ±1 LSB Matching | LSB不匹配时随机±1而非直接替换，避免直方图阶梯分布 |
| 3×3 块标记 | 每数据bit需9像素(中心1+标记8)，抗裁剪/压缩鲁棒性大幅提升 |
| 块级PRNG打乱 | 图片分3×3网格→Fisher-Yates打乱块顺序，容量精确无浪费 |
| 自适应通道 | 有A通道用4通道(A/B/G/R)，无A用3通道(B/G/R) |
| 格式保持 | RGB图保存为RGB，RGBA图保存为RGBA |

## 文件结构

```
watermark.h            # 接口定义
watermark.cpp          # 核心隐写引擎
watermark_tool.cpp     # 交互式命令行工具
test_watermark.cpp     # 自动化测试 (22项)
lodepng.h / lodepng.cpp # PNG编解码库
build_watermark.bat    # Windows一键编译脚本
```

## 编译 (Windows Dev-C++)

双击 `build_watermark.bat` 或手动:
```bat
g++ -std=c++17 -O2 -o watermark_tool.exe watermark_tool.cpp watermark.cpp lodepng.cpp
```

## 使用

### 交互模式
```
watermark_tool.exe
```
菜单: 嵌入水印 / 提取水印 / 查询容量

### 命令行模式
```bat
:: 嵌入水印
watermark_tool.exe embed input.png output.png 12345 "这是不可见水印"

:: 提取水印
watermark_tool.exe extract output.png 12345

:: 查询容量
watermark_tool.exe capacity input.png
```

## 容量参考

| 图片尺寸 | RGBA通道 | RGB通道 | 约可嵌入 |
|----------|----------|---------|---------|
| 100×100  | 1156 bits | 867 bits  | ~100 字节 |
| 200×200  | 17424 bits | 13068 bits | ~2174 字节 |
| 500×500  | 272224 bits | 204168 bits | ~34000 字节 |
| 1000×1000 | 1088888 bits | 816666 bits | ~136000 字节 |

注: 3×3块标记模式下，每个数据bit占9像素，容量约为像素数/9。

## 安全性

- **直方图无异常**: ±1嵌入不产生阶梯分布，RS/chi-square检测难发现
- **位置不可预测**: PRNG种子打乱块顺序，无种子无法定位嵌入位置
- **块标记验证**: 周边8像素标记可验证中心像素是否为有效数据块
- **格式无破绽**: 保持原图颜色类型，RGB不会变成RGBA
