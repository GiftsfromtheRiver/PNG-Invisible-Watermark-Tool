// watermark_tool automated test
#include "watermark.h"
#include "rs_codec.h"
#include "lodepng.h"
#include <iostream>
#include <cassert>
#include <vector>
#include <string>
#include <cstring>

using namespace watermark;
using namespace rs_codec;

static int pass = 0, fail = 0;

#define CHECK(cond, msg) do { \
    if (cond) { pass++; std::cout << "  [PASS] " << msg << "\n"; } \
    else { fail++; std::cout << "  [FAIL] " << msg << "\n"; } \
} while(0)

// Generate test PNG in current directory
static void make_test_png(const std::string& path, uint32_t w, uint32_t h, bool has_alpha) {
    std::vector<uint8_t> image(w * h * (has_alpha ? 4 : 3));
    uint64_t rng = 12345;
    for (size_t i = 0; i < image.size(); i++) {
        rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
        image[i] = rng & 0xFF;
    }
    unsigned error;
    if (has_alpha) {
        error = lodepng::encode(path, image, w, h, LCT_RGBA, 8);
    } else {
        error = lodepng::encode(path, image, w, h, LCT_RGB, 8);
    }
    if (error != 0) {
        std::cerr << "FATAL: cannot create " << path << " error=" << error << "\n";
        exit(1);
    }
}

// ========================================================================
// Original tests (backward compatibility)
// ========================================================================

void test_basic_embed_extract() {
    std::cout << "\n=== Basic Embed/Extract (no ECC) ===\n";
    
    make_test_png("test_wm_rgba.png", 100, 100, true);
    
    std::string text = "Hello, this is an invisible watermark!";
    uint64_t salt = 0xDEADBEEF;
    
    auto er = embed_text("test_wm_rgba.png", "test_wm_out_rgba.png", text, salt);
    CHECK(er.success, "RGBA embed ok");
    CHECK(er.used_bits > 0, "used " + std::to_string(er.used_bits) + " bits");
    
    auto xr = extract_text("test_wm_out_rgba.png", salt);
    CHECK(xr.success, "RGBA extract ok");
    CHECK(xr.text == text, "text matches: \"" + xr.text + "\"");
}

void test_rgb_image() {
    std::cout << "\n=== RGB (no Alpha, no ECC) ===\n";
    
    make_test_png("test_wm_rgb.png", 100, 100, false);
    
    auto cap = get_capacity("test_wm_rgb.png");
    CHECK(cap.has_alpha == false, "detected RGB (no A)");
    CHECK(cap.available_channels == 3, "3 channels available");
    
    std::string text = "RGB image watermark test 12345";
    uint64_t salt = 42;
    
    auto er = embed_text("test_wm_rgb.png", "test_wm_out_rgb.png", text, salt);
    CHECK(er.success, "RGB embed ok");
    CHECK(er.has_alpha == false, "output stays RGB");
    
    auto xr = extract_text("test_wm_out_rgb.png", salt);
    CHECK(xr.success, "RGB extract ok");
    CHECK(xr.text == text, "text matches");
}

void test_wrong_salt() {
    std::cout << "\n=== Wrong Salt ===\n";
    
    make_test_png("test_wm_salt.png", 80, 80, true);
    
    std::string text = "secret message";
    embed_text("test_wm_salt.png", "test_wm_salt_out.png", text, 111);
    
    auto xr = extract_text("test_wm_salt_out.png", 222);
    CHECK(xr.text != text, "wrong salt gives different text (correct!)");
}

void test_capacity_query() {
    std::cout << "\n=== Capacity Query ===\n";
    
    make_test_png("test_wm_cap.png", 200, 200, true);
    
    auto cap = get_capacity("test_wm_cap.png");
    CHECK(cap.width == 200, "width 200");
    CHECK(cap.height == 200, "height 200");
    CHECK(cap.has_alpha == true, "RGBA 4ch");
    CHECK(cap.blocks_per_channel > 0, "blocks/ch: " + std::to_string(cap.blocks_per_channel));
    CHECK(cap.max_text_bytes > 0, "max bytes: " + std::to_string(cap.max_text_bytes));
    
    std::cout << "  info: " << cap.width << "x" << cap.height 
              << " " << cap.available_channels << "ch"
              << " blocks/ch=" << cap.blocks_per_channel
              << " max=" << cap.max_text_bytes << "bytes\n";
}

void test_long_text() {
    std::cout << "\n=== Long Text (no ECC) ===\n";
    
    make_test_png("test_wm_long.png", 200, 200, true);
    
    auto cap = get_capacity("test_wm_long.png");
    
    std::string text(cap.max_text_bytes - 10, 'A');
    
    uint64_t salt = 9999;
    auto er = embed_text("test_wm_long.png", "test_wm_long_out.png", text, salt);
    CHECK(er.success, "long text embed ok (" + std::to_string(text.size()) + " bytes)");
    
    auto xr = extract_text("test_wm_long_out.png", salt);
    CHECK(xr.success, "long text extract ok");
    CHECK(xr.text == text, "long text matches");
}

void test_text_overflow() {
    std::cout << "\n=== Capacity Overflow ===\n";
    
    make_test_png("test_wm_tiny.png", 10, 10, true);
    
    auto cap = get_capacity("test_wm_tiny.png");
    
    std::string long_text(cap.max_text_bytes + 100, 'X');
    
    auto er = embed_text("test_wm_tiny.png", "test_wm_tiny_out.png", long_text, 0);
    CHECK(!er.success, "oversized text correctly rejected");
}

void test_multiline_text() {
    std::cout << "\n=== Multiline Text ===\n";
    
    make_test_png("test_wm_ml.png", 100, 100, true);
    
    std::string text = "line1\nline2\nline3\nHello World!\nlast line";
    uint64_t salt = 777;
    
    embed_text("test_wm_ml.png", "test_wm_ml_out.png", text, salt);
    auto xr = extract_text("test_wm_ml_out.png", salt);
    CHECK(xr.text == text, "multiline text matches");
}

void test_special_chars() {
    std::cout << "\n=== Special Characters ===\n";
    
    make_test_png("test_wm_special.png", 100, 100, true);
    
    std::string text = "symbols: <>&\"' | greek: alpha beta gamma | test123!@#";
    uint64_t salt = 555;
    
    embed_text("test_wm_special.png", "test_wm_special_out.png", text, salt);
    auto xr = extract_text("test_wm_special_out.png", salt);
    CHECK(xr.text == text, "special chars match");
}

// ========================================================================
// RS Codec unit tests
// ========================================================================

void test_rs_no_errors() {
    std::cout << "\n=== RS: No Errors ===\n";
    
    std::vector<uint8_t> data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int npar = 8;
    
    auto encoded = rs_encode(data, npar);
    CHECK(encoded.size() == 255, "encoded size = 255");
    CHECK(encoded[0] == 1 && encoded[1] == 2, "systematic: data at start");
    
    auto decoded = rs_decode(encoded, npar);
    CHECK(decoded.size() >= data.size(), "decoded size >= data size");
    
    bool match = true;
    for (size_t i = 0; i < data.size(); i++) {
        if (decoded[i] != data[i]) { match = false; break; }
    }
    CHECK(match, "decoded data matches original");
}

void test_rs_few_errors() {
    std::cout << "\n=== RS: Few Errors (within correction) ===\n";
    
    std::vector<uint8_t> data(50, 0);
    for (int i = 0; i < 50; i++) data[i] = i * 3 + 7;
    
    int npar = 16; // corrects 8 errors
    auto encoded = rs_encode(data, npar);
    
    // Inject 5 errors
    encoded[0] ^= 0x55;
    encoded[10] ^= 0xAA;
    encoded[50] ^= 0x33;
    encoded[100] ^= 0x77;
    encoded[200] ^= 0xFF;
    
    auto decoded = rs_decode(encoded, npar);
    CHECK(!decoded.empty(), "decode succeeded");
    
    bool match = !decoded.empty();
    for (size_t i = 0; i < data.size() && match; i++) {
        if (decoded[i] != data[i]) match = false;
    }
    CHECK(match, "all data corrected correctly");
}

void test_rs_too_many_errors() {
    std::cout << "\n=== RS: Too Many Errors ===\n";
    
    std::vector<uint8_t> data(20, 0);
    for (int i = 0; i < 20; i++) data[i] = i + 1;
    
    int npar = 8; // corrects 4
    auto encoded = rs_encode(data, npar);
    
    // Inject 6 errors (exceeds capability)
    for (int i = 0; i < 6; i++) {
        encoded[i * 10] ^= 0xFF;
    }
    
    auto decoded = rs_decode(encoded, npar);
    CHECK(decoded.empty(), "correctly detected too many errors");
}

void test_rs_multi_block() {
    std::cout << "\n=== RS: Multi-Block ===\n";
    
    std::vector<uint8_t> data(300, 0);
    for (int i = 0; i < 300; i++) data[i] = i & 0xFF;
    
    int npar = 8; // k=247, so 300 bytes -> 2 blocks
    auto encoded = rs_encode(data, npar);
    CHECK(encoded.size() == 510, "2 blocks = 510 bytes");
    
    // Inject errors in both blocks
    encoded[0] ^= 0x11;   // block 0
    encoded[260] ^= 0x22; // block 1
    
    auto decoded = rs_decode(encoded, npar);
    CHECK(!decoded.empty(), "multi-block decode succeeded");
    
    bool match = !decoded.empty();
    for (int i = 0; i < 300 && match; i++) {
        if (decoded[i] != data[i]) match = false;
    }
    CHECK(match, "multi-block data corrected");
}

void test_rs_max_correction() {
    std::cout << "\n=== RS: Max Correction (npar=8, 4 errors) ===\n";
    
    std::vector<uint8_t> data(100, 0);
    for (int i = 0; i < 100; i++) data[i] = (i * 7 + 13) & 0xFF;
    
    int npar = 8;
    auto encoded = rs_encode(data, npar);
    
    // Exactly 4 errors
    encoded[5] ^= 0x01;
    encoded[25] ^= 0x02;
    encoded[75] ^= 0x04;
    encoded[95] ^= 0x08;
    
    auto decoded = rs_decode(encoded, npar);
    CHECK(!decoded.empty(), "decode with 4 errors succeeded");
    
    bool match = !decoded.empty();
    for (int i = 0; i < 100 && match; i++) {
        if (decoded[i] != data[i]) match = false;
    }
    CHECK(match, "4 errors corrected correctly");
}

// ========================================================================
// ECC watermark integration tests
// ========================================================================

void test_ecc_embed_extract() {
    std::cout << "\n=== ECC Watermark: Embed/Extract ===\n";
    
    make_test_png("test_wm_ecc.png", 200, 200, true);
    
    std::string text = "ECC watermark test message!";
    uint64_t salt = 12345;
    
    // Test each ECC level
    for (int level = 1; level <= 4; level++) {
        int npar = ecc_level_to_npar(level);
        std::string fname = "test_wm_ecc_out_l" + std::to_string(level) + ".png";
        
        auto er = embed_text("test_wm_ecc.png", fname, text, salt, level);
        CHECK(er.success, "ECC level " + std::to_string(level) + " embed ok (used " + 
              std::to_string(er.used_bits) + " bits)");
        
        auto xr = extract_text(fname, salt, level);
        CHECK(xr.success, "ECC level " + std::to_string(level) + " extract ok");
        CHECK(xr.text == text, "ECC level " + std::to_string(level) + " text matches");
    }
}

void test_ecc_capacity_overflow() {
    std::cout << "\n=== ECC Watermark: Capacity Overflow ===\n";
    
    make_test_png("test_wm_ecc_tiny.png", 30, 30, true);
    
    auto cap = get_capacity("test_wm_ecc_tiny.png");
    std::cout << "  tiny image capacity: " << cap.max_text_bytes << " bytes\n";
    
    // With ECC, overhead reduces available space significantly
    std::string text(cap.max_text_bytes, 'X');
    
    auto er = embed_text("test_wm_ecc_tiny.png", "test_wm_ecc_tiny_out.png", text, 0, 2);
    // This might fail or succeed depending on exact capacity
    std::cout << "  ECC level 2 result: " << (er.success ? "success" : "rejected") << "\n";
    CHECK(true, "capacity check completed");
}

void test_ecc_backward_compat() {
    std::cout << "\n=== ECC Watermark: Backward Compatibility ===\n";
    
    make_test_png("test_wm_compat.png", 100, 100, true);
    
    std::string text = "backward compatible message";
    uint64_t salt = 999;
    
    // ecc_level=0 should behave exactly as before
    auto er = embed_text("test_wm_compat.png", "test_wm_compat_out.png", text, salt, 0);
    CHECK(er.success, "ecc_level=0 embed ok");
    
    auto xr = extract_text("test_wm_compat_out.png", salt, 0);
    CHECK(xr.success, "ecc_level=0 extract ok");
    CHECK(xr.text == text, "ecc_level=0 text matches");
}

void test_ecc_wrong_level() {
    std::cout << "\n=== ECC Watermark: Wrong ECC Level ===\n";
    
    make_test_png("test_wm_ecc_wrong.png", 200, 200, true);
    
    std::string text = "ecc level mismatch test";
    uint64_t salt = 777;
    
    auto er = embed_text("test_wm_ecc_wrong.png", "test_wm_ecc_wrong_out.png", text, salt, 2);
    CHECK(er.success, "embed with ecc_level=2 ok");
    
    // Try to extract with wrong level
    auto xr = extract_text("test_wm_ecc_wrong_out.png", salt, 3);
    CHECK(!xr.success || xr.text != text, "wrong ecc level: different result (correct!)");
}

int main() {
    std::cout << "========================================\n";
    std::cout << "  PNG Watermark Tool - Automated Test\n";
    std::cout << "  (with Reed-Solomon ECC)\n";
    std::cout << "========================================\n";
    
    // Original tests (backward compatibility)
    test_basic_embed_extract();
    test_rgb_image();
    test_wrong_salt();
    test_capacity_query();
    test_long_text();
    test_text_overflow();
    test_multiline_text();
    test_special_chars();
    
    // RS codec unit tests
    test_rs_no_errors();
    test_rs_few_errors();
    test_rs_too_many_errors();
    test_rs_multi_block();
    test_rs_max_correction();
    
    // ECC watermark integration tests
    test_ecc_embed_extract();
    test_ecc_capacity_overflow();
    test_ecc_backward_compat();
    test_ecc_wrong_level();
    
    std::cout << "\n========================================\n";
    std::cout << "  Result: " << pass << " passed, " << fail << " failed\n";
    std::cout << "========================================\n";
    
    return fail > 0 ? 1 : 0;
}
